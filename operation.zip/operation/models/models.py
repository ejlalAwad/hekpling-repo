# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class Operation(models.Model):
    _name = 'operation.site.survey'
    _description = 'operation.site.survey'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Site Survey No", copy=False, default='New', readonly=True)
    state = fields.Selection([('draft', 'Draft'),
                              ('procurement', 'Sent to Procurement'),
                              ('procurement_update', 'Procurement Details Updated '),
                              ('approve', 'Approve'),
                              ('amend', 'Under Amendment'),
                              ('cancel', 'Cancelled')]
                            , default='draft')
    site_sur_date = fields.Date(string="Site Survey Date")
    enquiry_id = fields.Char(string="Enquiry No")
    project_id = fields.Many2one("project.project", string="Project")
    project_code = fields.Many2one("project.project", string="Project Code")
    branch_id = fields.Many2one("project.project", string="Branch")
    customer_id = fields.Many2one("res.partner", string="Customer")
    reason_cancel = fields.Char(string="Reason for Cancellation")
    # send_to_pre = fields.Boolean(string="Send to Procurement")
    reason_deletion = fields.Char(string="Reason for Deletion")
    amendment_ids = fields.One2many("amendment.amendment", 'operation_id')
    site_sur_content_ids = fields.One2many("site.survey.content", 'operation_id')
    site_sur_product_ids = fields.One2many("site.survey.product", 'operation_id')
    site_sur_equipment_ids = fields.One2many("site.survey.equipment", 'operation_id')
    manpower_count_ids = fields.One2many("manpower.count", 'operation_id')
    manpower_details_ids = fields.One2many("manpower.details", 'operation_id')
    company_id = fields.Many2one('res.company', string='Company', index=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id', readonly=True)
    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_amount_all',
                                     tracking=5, currency_field='currency_id',)
    amount_tax = fields.Monetary(string='Taxes', store=True, readonly=True, compute='_amount_all')
    amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_all', tracking=4)

    @api.depends('site_sur_product_ids.price_total')
    def _amount_all(self):
        """
        Compute the total amounts of the site survey.
        """
        for operation in self:
            amount_untaxed = amount_tax = 0.0
            for line in operation.site_sur_product_ids:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
            operation.update({
                'amount_untaxed': amount_untaxed,
                'amount_tax': amount_tax,
                'amount_total': amount_untaxed + amount_tax,
            })

    def sent_to_procurement(self):
        self.write({'state': 'procurement'})

    def procurement_update(self):
        self.write({'state': 'procurement_update'})

    def approve(self):
        self.write({'state': 'approve'})

    def amend(self):
        self.write({'state': 'amend'})

    def cancel(self):
        self.write({'state': 'cancel'})

    def action_return(self):
        self.write({'state': 'draft'})

    @api.model
    def create(self, data_list):
        data_list['name'] = self.env['ir.sequence'].next_by_code('operation.site.survey')
        return super(Operation, self).create(data_list)


class Amendment(models.Model):
    _name = 'amendment.amendment'
    _description = 'Amendment'

    operation_id = fields.Many2one("operation.site.survey", string="Survey")
    amendment_date = fields.Date(string="Amendment Date")
    amendment_no = fields.Char(string="Amendment No")


class SiteSurveyContent(models.Model):
    _name = 'site.survey.content'
    _description = 'site.survey.content'

    operation_id = fields.Many2one("operation.site.survey", string="Survey")
    name = fields.Char(string="Survey Content")
    observations = fields.Text(string="Observations")
    remarks = fields.Text(string="Remarks")


class SiteSurveyProduct(models.Model):
    _name = 'site.survey.product'
    _res_name = 'product_id'
    _description = 'site.survey.product'

    operation_id = fields.Many2one("operation.site.survey", string="Survey")
    product_id = fields.Many2one('product.product', string="Product")
    description = fields.Text(string="Description")
    category_id = fields.Many2one('product.category', 'Product Category', help="Select category for the current product")
    product_uom_qty = fields.Float(string="Quantity", default=0)
    uom_id = fields.Many2one(related='product_id.product_tmpl_id.uom_id', string="Unit Of Measure")
    tax_id = fields.Many2many('account.tax', string='Taxes',
                              domain=['|', ('active', '=', False), ('active', '=', True)])
    company_id = fields.Many2one('res.company', string='Company', index=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id', readonly=True)
    price_unit = fields.Monetary(string='Unit Price', currency_field='currency_id')
    price_subtotal = fields.Monetary(compute='_compute_amount', string='Subtotal', readonly=True, store=True) # currency_field='currency_id',
    price_tax = fields.Float(compute='_compute_amount', string='Total Tax', readonly=True, store=True)
    price_total = fields.Monetary(compute='_compute_amount', string='Total', readonly=True, store=True)
    discount = fields.Float(string='Discount (%)', digits='Discount', default=0.0)

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id')
    def _compute_amount(self):
        """
        Compute the amounts of the product line.
        """
        for line in self:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            taxes = line.tax_id.compute_all(price, line.currency_id, line.product_uom_qty,
                                            product=line.product_id, partner=line.operation_id.customer_id)
            line.update({
                'price_tax': sum(t.get('amount', 0.0) for t in taxes.get('taxes', [])),
                'price_total': taxes['total_included'],
                'price_subtotal': taxes['total_excluded'],
            })
            if self.env.context.get('import_file', False) and not self.env.user.user_has_groups(
                    'account.group_account_manager'):
                line.tax_id.invalidate_cache(['invoice_repartition_line_ids'], [line.tax_id.id])


class SiteSurveyEquipment(models.Model):
    _name = 'site.survey.equipment'
    _inherit = 'site.survey.product'
    _description = 'site.survey.equipment'


class ManpowerCount(models.Model):
    _name = 'manpower.count'
    _description = 'Manpower count'

    operation_id = fields.Many2one("operation.site.survey", string="Survey")
    jop_costing_id = fields.Many2one("job.costing.details", string="Job Costing Details")
    security_guard = fields.Integer(string="Security Guard")
    shift_supervisor = fields.Integer(string="Shift Supervisor")
    senior_shift_supervisor = fields.Integer(string="Senior Shift Supervisor")
    total = fields.Integer(string="Total", compute='_compute_total')

    @api.depends('security_guard', 'shift_supervisor', 'senior_shift_supervisor')
    def _compute_total(self):
        for rec in self:
            rec.total = (rec.security_guard + rec.shift_supervisor + rec.senior_shift_supervisor)


class ManpowerDetails(models.Model):
    _name = 'manpower.details'
    _inherit = 'manpower.count'
    _description = 'Manpower Details'

    security_guard = fields.Selection([('no', 'NO'),
                                      ('yes', 'Yes')]
                                      , default='no', string="Security Guard")
    shift_supervisor = fields.Selection([('no', 'NO'),
                                        ('yes', 'Yes')]
                                        , default='no', string="Shift Supervisor")
    senior_shift_supervisor = fields.Selection([('no', 'NO'),
                                               ('yes', 'Yes')]
                                               , default='no', string="Senior Shift Supervisor")


class JobCosting(models.Model):
    _name = 'job.costing.details'
    _description = 'job.costing.details'

    name = fields.Char("Job Costing Details")

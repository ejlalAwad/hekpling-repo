# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class ReasonForCancellation(models.TransientModel):
    _name = 'reason.cancellation'
    _description = 'Reason for Cancellation'

    reason = fields.Char(string='Reason for Cancellation', required=True)

    def cancel(self):
        active_id = self.env.context.get('active_id')
        if active_id:
            operation_id = self.env['operation.site.survey'].browse(active_id)
            if operation_id:
                res = {
                    'reason_cancel': self.reason,
                    'state': 'cancel'
                }
                operation_id.update(res)
        return {'type': 'ir.actions.act_window_close'}

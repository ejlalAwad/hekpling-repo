# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class UnderAmendment(models.TransientModel):
    _name = 'under.amendment'
    _description = 'under.amendment'

    amend_no = fields.Char(string='Amendment No')
    amend_date = fields.Date(string='Amendment Date')

    def amendment(self):
        active_id = self.env.context.get('active_id')
        res = []
        if active_id:
            operation_id = self.env['operation.site.survey'].browse(active_id)
            if operation_id:
                dit = {
                    'amendment_date': self.amend_date,
                    'amendment_no': self.amend_no,
                }
                res.append((0, 0, dit))
                operation_id.update({'amendment_ids': res, 'state': 'amend'})
        return {'type': 'ir.actions.act_window_close'}
